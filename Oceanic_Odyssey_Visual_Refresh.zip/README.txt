MY OCEANIC ODYSSEY VISUAL REFRESH — REVIEW BUILD

Copy the included HTML files and odyssey-theme.css into the root of your Oahu_Paddle Codespace. Keep every existing file that is not included, especially styles.css, gallery_style.css, JavaScript, photos, route data, and map assets.

To preview locally: python3 -m http.server 8000
Then open the forwarded port. Do not push to main until reviewed.

What changed: font link to Manrope + DM Sans, an additive shared theme CSS override, Open Oceanography navigation link on desktop and mobile drawer, and a link to the live standalone science site from the existing science archive page. No stories or Javascript were altered.

To revert: restore original HTML files and remove odyssey-theme.css.
