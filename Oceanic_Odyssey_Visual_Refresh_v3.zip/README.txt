My Oceanic Odyssey visual refresh v3

Based on approved v2 visual refresh. Removes duplicate Science navigation and drawer links; retains one direct Open Oceanography link at https://openoceanography.science/. Science page is intentionally excluded. No script, map, gallery, or story code modified.

In your website-redesign Codespace branch, unzip with unzip -o Oceanic_Odyssey_Visual_Refresh_v3.zip, then run rm science.html to remove the obsolete local page. Preview before committing. Do not touch main until approved.
