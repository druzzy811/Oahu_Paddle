MY OCEANIC ODYSSEY — VISUAL REFRESH v2

Keep working on your website-redesign branch. Extract this ZIP into the Oahu_Paddle repository root, overwriting the previous preview files.

New in v2: 2-level footer shared in structure with Open Oceanography, roomier expedition introduction and map presentation, chapter collection styling, editorial type and spacing and responsive refinements. Existing Oahu SVG, all JS, gallery data, maps, photos and article prose are NOT changed.

Preview with python3 -m http.server 8000; open the forwarded port. Test index.html, TableofContents.html, gallery.html, introduction.html, and other pages on desktop and mobile before pushing or merging.

Files included: 9 HTML files and odyssey-theme.css. No Javascript or other existing assets are included or replaced.
